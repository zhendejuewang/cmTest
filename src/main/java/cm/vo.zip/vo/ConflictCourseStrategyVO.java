package cm.vo;

import lombok.Data;

/**
 * @Author: Yunfeng Huang
 * @Description:
 * @Date: Created in 2018/12/30
 */
@Data
public class ConflictCourseStrategyVO {
    private Long id;
    private Long courseId;
}
