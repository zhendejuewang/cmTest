package cm.vo;

import lombok.Data;
/**
 * @Author: Yunfeng Huang
 * @Description:
 * @Date: Created in 2018/12/21
 */
@Data
public class UrlVO {
    private String url;
}
